# Kaizonigma Patch Guide

## How-To: Patching a BPS File with the Original ROM

### What You Need:

1. **Original ROM File**: Make sure you have the original ROM file named **Tenchi Souzou (Japan).sfc**. The patch will be applied to this file.
2. **BPS Patching Tool**: You can use tools like **Flips** or **Beat** to apply the `.bps` file.

### Step-by-Step Guide

#### 1. Download Required Software

- Download and install a BPS patching tool, such as **Flips** or **Beat**.

#### 2. Extract the Software

- Extract the downloaded ZIP file into a folder on your computer.

#### 3. Prepare Original ROM and Patch File

- Ensure you have the original ROM file named **Tenchi Souzou (Japan).sfc** and the `.bps` patch file (e.g., `Kaizonigma.bps`) in the same folder where you extracted the patching software.

#### 4. Launch the Patching Tool

- **Flips**:
  1. Open the Flips application.
  2. Select the option “Apply patch.”
  3. Choose the `.bps` file you want to apply (e.g., `Kaizonigma.bps`).
  4. Select the original ROM file (e.g., `Tenchi Souzou (Japan).sfc`).
  5. Click “Apply” to start the patching process.
  6. Save the patched file to your desired location (e.g., `Kaizonigma_Patched.sfc`).

- **Beat**:
  1. Launch Beat.
  2. Select the option “Patch ROM.”
  3. Choose the `.bps` file (e.g., `Kaizonigma.bps`).
  4. Select the original ROM file (e.g., `Tenchi Souzou (Japan).sfc`).
  5. Click “Patch” to initiate the process.
  6. Save the patched file.

#### 5. Using the Patched ROM

- After successfully patching, you should be able to use the new patched ROM file (e.g., `Kaizonigma_Patched.sfc`). Load this file in your preferred SNES emulator or play it on an SNES flashcart.

### Notes:

- Ensure that the original ROM you are using is the correct version, as some patches target specific ROM versions.
- It’s advisable to keep a backup copy of your original ROM in case anything goes wrong during the patching process.

With this guide, you should be able to successfully apply the `.bps` file to the original **Tenchi Souzou (Japan).sfc** ROM. If you have any questions or need assistance, feel free to ask!
